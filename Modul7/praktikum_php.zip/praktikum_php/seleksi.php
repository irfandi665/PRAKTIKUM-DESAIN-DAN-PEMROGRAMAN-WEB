<?php 
echo $_POST ['nama']=""."<br>"
	.$_POST ['usia']=""."<br>"
	.$_POST ['gender']=""."<br>"
 ?>

<!DOCTYPE html>
<html>
<head>
	<style>
		body{
	background:#96C7C1;
	font-family: poppins;
}
	</style>
	<meta charset="utf-8">
	<title>Seleksi</title>
	<link rel="stylesheet" type="text/css" href="css/seleksi.css">
</head>
<body>
	<div class="seleki">
	<h2>Selamat berkesempatan menjadi Power Rangers
		<br> Silahkan pilih Rangers anda!</h2>
		<a href="pilih.php"> Klik disini untuk memilih</a></div>
</body>
</html>